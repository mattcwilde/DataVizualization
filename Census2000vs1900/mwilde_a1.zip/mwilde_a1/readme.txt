Matthew Wilde
netid: mwilde

Looking at the data, I felt the most interesting question was the relative number of men to women at each age group and how that has changed over a century. Though, this is rather simplistic, I believe it to be the most interesting feature in the data. Taking the ratio of men to women at each century we can see the answer to the relevent question. The most striking feature is the relative increase in women to men in the modern era. 

By taking the ratio, we hide the overall population growth, which I felt was obvious and not interesting. This scaling highlights the "bump" in middle aged men in 1900 and the faster decline of men to women in later life. 

As for the design choices, I chose to use grey scale colors based on Tableaus color blind safe color scheme. Also, in the name of inclusion, I have used sans-serif fonts as these are purported to be better for the dyslexic. I felt the plot boundaries are uneccesary and chose to add a grid to guide the eye in seeing he different age groups. I added the legend to the lower left to avoid the uneccesarry white space. I also cut the limits of the y-axis for the same reason. 
